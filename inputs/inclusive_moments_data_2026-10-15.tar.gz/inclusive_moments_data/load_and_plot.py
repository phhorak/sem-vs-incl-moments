#!/usr/bin/env python3
"""Load the inclusive B -> X_c l nu moment data of the kolya_fit fits and plot it.

The data vector and its block-diagonal covariance are assembled exactly as
kolya_fit/fitting.py:prepare_fitting_data() does it: one block per (experiment set,
observable) in the order the fit's prediction vector uses, each block read from its own
HDF5 file and passed through statsmodels' cov_nearest with the same clipping threshold.

  python3 load_and_plot.py                       # default selection -> moments_data.pdf
  python3 load_and_plot.py --selection selections/noBelleq2.json
  python3 load_and_plot.py --dump moments.csv    # also write the data vector as CSV
"""
import argparse
import json
import os

import numpy as np
import pandas as pd
from statsmodels.stats.correlation_tools import cov_nearest

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "data")

# Smallest eigenvalue cov_nearest leaves in the correlation matrix of an experimental
# covariance; same value as kolya_fit.utils.COVARIANCE_CLIP_THRESHOLD.
COVARIANCE_CLIP_THRESHOLD = 10e-7

# One covariance block each, in the order in which the measurements enter the data vector:
# q2 first, then MX, then El, and within each observable in the order of the experiments.
# Copied from kolya_fit.fitting.DATA_SOURCES.
DATA_SOURCES = [
    (["belle", "belleII"], "q2", "avg_belle_belleII_combined_central.h5", "avg_belle_belleII_combined_central_cov.h5"),
    (["babar"],  "mx", "babar_central.h5",  "babar_covariance.h5"),
    (["belle"],  "mx", "belle_central.h5",  "belle_covariance.h5"),
    (["cdf"],    "mx", "cdf_central.h5",    "cdf_covariance.h5"),
    (["cleo"],   "mx", "cleo_central.h5",   "cleo_covariance.h5"),
    (["delphi"], "mx", "delphi_central.h5", "delphi_covariance.h5"),
    (["babar"],  "el", "babar_central.h5",  "babar_covariance.h5"),
    (["belle"],  "el", "belle_central.h5",  "belle_covariance.h5"),
    (["delphi"], "el", "delphi_central.h5", "delphi_covariance.h5"),
]

# Row keys are "<observable>_<n>_<experiment>": el_0 is the partial semileptonic rate
# DeltaGamma(E_l > E_cut) in GeV (multiply by tau_B / hbar for the partial branching
# fraction), the remaining entries are the centralised moments of Eqs. (2.8)-(2.10) of
# the paper.  Cuts are E_cut in GeV for mx/el and q2_cut in GeV^2 for q2.
LABELS = {
    ("q2", 1): r"$\langle q^2 \rangle$ in GeV$^2$",
    ("q2", 2): r"$\langle (q^2 - \langle q^2 \rangle)^2 \rangle$ in GeV$^4$",
    ("q2", 3): r"$\langle (q^2 - \langle q^2 \rangle)^3 \rangle$ in GeV$^6$",
    ("q2", 4): r"$\langle (q^2 - \langle q^2 \rangle)^4 \rangle$ in GeV$^8$",
    ("mx", 1): r"$\langle M_X^2 \rangle$ in GeV$^2$",
    ("mx", 2): r"$\langle (M_X^2 - \langle M_X^2 \rangle)^2 \rangle$ in GeV$^4$",
    ("mx", 3): r"$\langle (M_X^2 - \langle M_X^2 \rangle)^3 \rangle$ in GeV$^6$",
    ("el", 0): r"$\Delta\Gamma(E_\ell > E_\mathrm{cut})$ in GeV",
    ("el", 1): r"$\langle E_\ell \rangle$ in GeV",
    ("el", 2): r"$\langle (E_\ell - \langle E_\ell \rangle)^2 \rangle$ in GeV$^2$",
    ("el", 3): r"$\langle (E_\ell - \langle E_\ell \rangle)^3 \rangle$ in GeV$^3$",
}
XLABEL = {"q2": r"$q^2_\mathrm{cut}$ in GeV$^2$", "mx": r"$E_\mathrm{cut}$ in GeV",
          "el": r"$E_\mathrm{cut}$ in GeV"}


def build_indices(selection, experiments, observable):
    """(row key, cut) pairs of `selection`, in the order the fit uses."""
    return [
        (f"{moment}_{experiment}", cut)
        for experiment in selection if experiment in experiments
        for moment in selection[experiment] if moment[:2] == observable
        for cut in selection[experiment][moment]
    ]


def load(selection):
    """Assemble the data vector and covariance of one data selection.

    Returns a DataFrame with one row per measurement (experiment, observable, order, cut,
    value, error) and the block-diagonal covariance, both in the fit's ordering.
    """
    rows, blocks = [], []
    for experiments, observable, central_file, covariance_file in DATA_SOURCES:
        indices = build_indices(selection, experiments, observable)
        if not indices:  # every cut of this block was dropped from the selection
            continue
        central = pd.read_hdf(os.path.join(DATA_DIR, central_file))
        covariance = pd.read_hdf(os.path.join(DATA_DIR, covariance_file))
        block = cov_nearest(covariance.loc[indices, indices].values,
                            threshold=COVARIANCE_CLIP_THRESHOLD)
        blocks.append(block)
        for (key, cut), value, error in zip(indices, central.loc[indices, "Values"].values,
                                            np.sqrt(np.diag(block))):
            moment, order, experiment = key.rsplit("_", 2)[0], int(key.split("_")[1]), key.split("_", 2)[2]
            rows.append(dict(experiment=experiment, observable=moment, order=order,
                             cut=cut, value=value, error=error))
    data = pd.DataFrame(rows)
    size = sum(len(b) for b in blocks)
    C = np.zeros((size, size))
    start = 0
    for block in blocks:  # block diagonal: the experiments are taken as uncorrelated
        C[start:start + len(block), start:start + len(block)] = block
        start += len(block)
    return data, C


def correlation_eigenvalues(C):
    """Eigenvalues of the correlation matrix of `C` -- dimensionless, unlike those of `C`."""
    scale = np.sqrt(np.diag(C))
    return np.linalg.eigvalsh(C / np.outer(scale, scale))


def plot(data, outfile):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    panels = sorted(set(zip(data.observable, data.order)),
                    key=lambda p: (["q2", "mx", "el"].index(p[0]), p[1]))
    ncols = 4
    nrows = -(-len(panels) // ncols)
    fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 3 * nrows), dpi=120)
    for ax, (observable, order) in zip(axes.flat, panels):
        panel = data[(data.observable == observable) & (data.order == order)]
        for experiment, group in panel.groupby("experiment"):
            ax.errorbar(group.cut, group.value, yerr=group.error, marker="o", ls="none",
                        capsize=2, label=experiment)
        ax.set_xlabel(XLABEL[observable])
        ax.set_ylabel(LABELS[(observable, order)], fontsize=9)
        ax.legend(fontsize=8)
    for ax in axes.flat[len(panels):]:
        ax.axis("off")
    fig.tight_layout()
    fig.savefig(outfile)
    print("Wrote", outfile)


def demo():
    """Self-check on the default selection: sizes, errors and covariance consistency."""
    with open(os.path.join(HERE, "selections", "default.json")) as f:
        data, C = load(json.load(f))
    assert len(data) == 74 == len(C), (len(data), len(C))
    assert np.allclose(np.sqrt(np.diag(C)), data.error.values)
    assert np.allclose(C, C.T)
    # Positive definiteness is tested on the correlation matrix: the data vector mixes
    # el_0 (~1e-14 GeV) with moments of order one, so eigenvalues of C itself carry units.
    assert correlation_eigenvalues(C).min() > 0, "covariance is not positive definite"
    # The blocks are ordered q2, then mx, then el, as the prediction vector expects.
    assert list(data.observable.unique()) == ["q2", "mx", "el"]
    print("demo: ok")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--selection", default=os.path.join(HERE, "selections", "default.json"),
                        help="JSON file listing the measurements entering the fit")
    parser.add_argument("--output", default="moments_data.pdf", help="figure to write")
    parser.add_argument("--dump", help="also write the data vector to this CSV file")
    parser.add_argument("--demo", action="store_true", help="run the self-check and exit")
    args = parser.parse_args()

    if args.demo:
        demo()
        raise SystemExit

    with open(args.selection) as f:
        data, C = load(json.load(f))

    print(f"{os.path.basename(args.selection)}: {len(data)} measurements")
    print(data.to_string(index=False, float_format=lambda v: f"{v:.6g}"))
    print(f"covariance: {C.shape[0]}x{C.shape[1]}, smallest correlation eigenvalue "
          f"{correlation_eigenvalues(C).min():.3e}")
    if args.dump:
        data.to_csv(args.dump, index=False)
        np.savetxt(args.dump.replace(".csv", "_covariance.txt"), C)
        print("Wrote", args.dump, "and", args.dump.replace(".csv", "_covariance.txt"))
    plot(data, args.output)
