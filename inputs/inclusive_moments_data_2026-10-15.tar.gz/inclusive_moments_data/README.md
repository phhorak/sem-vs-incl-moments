# Inclusive B -> X_c l nu moment data

The experimental input of the kolya_fit moment fits, in particular of the default
1/m_b^3 fit (`config/moments/data/default.json` + `config/moments/settings/NLOpw_1_NNLO_1_mb3.json`,
here `selections/default.json` + `fit_settings_NLOpw_1_NNLO_1_mb3.json`).

## Contents

    data/*.h5                 central values and covariances, one pair per experiment
    selections/default.json   the measurements entering the default fit (74 of them)
    selections/no*.json       the leave-one-out selections of the validation fits
    fit_settings_NLOpw_1_NNLO_1_mb3.json   kolya settings of the default 1/m_b^3 fit
    load_and_plot.py          assembles the data vector + covariance and plots them

## Format

Each `*_central.h5` / `*_covariance.h5` pair is a pandas object with a two-level index
`(<observable>_<n>_<experiment>, cut)`:

* `q2_n` – centralised q^2 moments q_n, cut = q^2_cut in GeV^2, value in GeV^(2n)
* `mx_n` – centralised M_X^2 moments h_n, cut = E_cut in GeV, value in GeV^(2n)
* `el_n`, n >= 1 – centralised lepton energy moments l_n, cut = E_cut in GeV, value in GeV^n
* `el_0` – partial semileptonic rate DeltaGamma(E_l > E_cut) in GeV; multiply by
  tau_B / hbar for the partial branching fraction

The moment definitions are Eqs. (2.8)–(2.10) of the paper (kinematic moments centralised
about their own mean). The q^2 moments of Belle and Belle II come from their combined
file, whose covariance correlates the two experiments; all other blocks are taken as
mutually uncorrelated, so the fit covariance is block diagonal.

A selection JSON lists, per experiment and moment, the cuts that enter the fit. The files
hold more cuts than any fit uses — the fit only ever reads the subset the selection names,
which is what keeps the covariance blocks invertible.

## Using it

    pip install numpy pandas tables matplotlib statsmodels

    python3 load_and_plot.py                              # print the 74 measurements, write moments_data.pdf
    python3 load_and_plot.py --selection selections/noBelleq2.json
    python3 load_and_plot.py --dump moments.csv           # data vector as CSV + covariance as text
    python3 load_and_plot.py --demo                       # self-check

`load(selection)` returns the data vector as a DataFrame and the block-diagonal
covariance, assembled exactly as `kolya_fit/fitting.py:prepare_fitting_data()` does it:
same block order (q^2, then M_X^2, then E_l; experiments in the order of `DATA_SOURCES`),
same `cov_nearest` clipping at 1e-6 of the correlation eigenvalues. The ordering is the one
the fit's prediction vector assumes, so `chi2 = (m - x) C^-1 (m - x)` with `m` in that same
order reproduces the fit's chi2.

Caveat carried over from the fit: after clipping, the smallest correlation eigenvalue of
the default data set is ~1e-6, i.e. at the clipping threshold — that direction (inside the
combined Belle/Belle II q^2 block) is fixed by `cov_nearest`, not by the measurements.
